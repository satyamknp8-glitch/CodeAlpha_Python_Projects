# Task 1: Iris Flower Classification (CodeAlpha)

## What this does
- Loads the classic Iris dataset (150 samples, 3 species: setosa, versicolor, virginica) using `sklearn.datasets.load_iris` — no manual download needed, it comes bundled with Scikit-learn.
- Explores the data (summary stats, class balance, pairplot, correlation heatmap).
- Splits into train/test (80/20, stratified), scales features.
- Trains and compares 5 models: Logistic Regression, Decision Tree, Random Forest, SVM, KNN.
- Evaluates the best model with accuracy, classification report, and a confusion matrix.

## How to run
```
pip install scikit-learn pandas matplotlib seaborn
python iris_classification.py
```

## Results (this run)
| Model | Accuracy |
|---|---|
| Logistic Regression | 93.3% |
| Decision Tree | 93.3% |
| Random Forest | 90.0% |
| **SVM (linear)** | **100%** |
| K-Nearest Neighbors | 93.3% |

SVM was the best performer on the test set (30 samples), with perfect precision/recall across all 3 species.

## Files produced
- `iris_pairplot.png` – feature relationships colored by species
- `iris_correlation_heatmap.png` – feature correlation
- `iris_model_comparison.png` – bar chart comparing all 5 models
- `iris_confusion_matrix.png` – confusion matrix of the best model
- `iris_dataset.csv` – the dataset used

## Note for your submission
If CodeAlpha's task page has a specific CSV to download (their "here" link), you can swap it in — just replace the `load_iris()` call with `pd.read_csv("your_file.csv")` and keep the same column names (or adjust the feature list at the top).
