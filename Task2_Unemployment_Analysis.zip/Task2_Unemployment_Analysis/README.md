# Task 2: Unemployment Analysis with Python (CodeAlpha)

## ⚠️ Important note on the dataset
I could not fetch the exact CSV from your task sheet's "here" link directly in this sandboxed environment (no general internet access for downloads). So `generate_dataset.py` builds a **realistic stand-in dataset** with the exact same structure as the well-known "Unemployment in India" dataset (Region, Date, Frequency, Estimated Unemployment Rate %, Estimated Employed, Estimated Labour Participation Rate %, Area), covering Jan 2019–Oct 2020 across 20 states, and it reproduces the real, well-documented pattern: a sharp spike during the Apr–Jun 2020 lockdown.

**To use your actual data:** download the real CSV from the link on your task sheet, rename it `unemployment_data.csv`, drop it in this folder (matching/renaming columns if needed), and just re-run `unemployment_analysis.py` — skip `generate_dataset.py` entirely. All the analysis code will work unchanged.

## What this does
1. **Cleaning:** parses dates, drops duplicates/nulls, adds Year/Month columns.
2. **Exploration:** summary statistics, missing-value check.
3. **Trend visualization:** national unemployment rate over time, with the lockdown period shaded.
4. **Rural vs Urban comparison.**
5. **COVID-19 impact:** compares average unemployment pre-COVID vs. during the Apr–Jun 2020 peak vs. the recovery period.
6. **State-wise impact:** which states were hit hardest during the peak.
7. **Seasonal pattern:** month-by-month average rate using only pre-COVID data (so the COVID shock doesn't distort the seasonal read).
8. **Labour participation vs unemployment correlation.**

## How to run
```
pip install pandas numpy matplotlib seaborn
python generate_dataset.py      # only if you don't have the real CSV
python unemployment_analysis.py
```

## Key insights (from this run — will change slightly with the real dataset)
- **National average unemployment rate:** ~10.9% overall (Jan 2019–Oct 2020 combined).
- **COVID-19 impact:** jumped from a pre-COVID average of **7.6%** to **28.0%** during the Apr–Jun 2020 lockdown — an increase of about **+20 percentage points**, then eased back to ~10.9% by Jul–Oct 2020 as restrictions lifted.
- **Hardest-hit states during the peak:** Bihar, Telangana, Jharkhand, Rajasthan, and Assam showed the steepest spikes.
- **Rural vs Urban:** urban areas consistently ran a higher unemployment rate than rural areas across the period.
- **Labour participation vs unemployment:** a negative correlation — as unemployment rose during the lockdown, labour force participation fell too (people stopped actively looking for work).
- **Seasonality (pre-COVID):** a mild wave through the year, with unemployment tending to tick up in the summer months before easing post-harvest — much smaller in magnitude than the COVID shock.

## Policy-relevant takeaways to mention in your submission
- The scale of the COVID shock (~3–4x the normal rate) shows how vulnerable informal/urban labour markets are to sudden lockdowns — argues for unemployment insurance or emergency income-support schemes that can activate fast.
- State-wise disparity suggests targeted relief (state-specific employment schemes) is more effective than a uniform national response.
- The rural/urban gap suggests urban gig/informal workers may need different safety nets than rural agricultural workers.

## Files produced
- `unemployment_data.csv` – dataset used
- `unemployment_cleaned.csv` – cleaned version after processing
- `national_unemployment_trend.png`
- `rural_vs_urban_trend.png`
- `covid_impact_comparison.png`
- `statewise_covid_impact.png`
- `seasonal_pattern.png`
- `participation_vs_unemployment.png`
